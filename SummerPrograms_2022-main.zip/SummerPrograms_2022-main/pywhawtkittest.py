import pywhatkit as kt

print("Searching")



target1 = 'How to print '

kt.search(target1)


