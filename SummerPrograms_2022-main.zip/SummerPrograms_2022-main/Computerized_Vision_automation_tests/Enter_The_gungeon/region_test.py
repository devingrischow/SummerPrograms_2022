import pyautogui
import os

# from os import listdir

# folder_dir = "D:\Summer_Programs_2021\Computerized_Vision_automation_tests\Enter_The_gungeon\Tracked_objects\Player_track"
# for images in os.listdir(folder_dir):
 
#     # check if the image ends with png
#     if (images.endswith(".png")):
#         pyautogui.locateOnScreen(images)




