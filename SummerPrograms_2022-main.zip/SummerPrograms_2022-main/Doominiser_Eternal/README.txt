This Program Is terminal based, Reason being is its my first program Ive made solo, and I couldnt manage to get the GUI to work with the randomizer. But thats not to say the program is complicated, in fact far from it. 


CONTROLS: 
-To start the program run the doom_mouse_detection.py file
-When starting the program, type K into the Terminal bar, after that you will have 4 seconds till the program starts detecting clicks. 
How its works is a random number between 1 and 7 is generated, that number is then sent to a function to press that same number, switching faster than any human could ever need or want too! This may sound bad, but in many situations the randomizer can select a combination of guns that absolutely destroy any demon in your path. 
Except the Marauder, the only best combo to kill them is still super-ballista. 
- To stop the program, press CTRL + C, this is how to get the python interpuritor to stop everything, as currently there is no exit looping function. 


Potential future plans: 
have each weapon have its own optimized unique switching time, currently all single shot guns swap every half second, and hold to fire wait till your done and then swap at 3 seconds. 
I dont plan to just abandon this entirely, I want to add a stop key and a pause key and In the future I will know how to do it, but for now I want to start working on another small program. 


